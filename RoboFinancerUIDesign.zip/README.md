
  # RoboFinancer UI Design

  This is a code bundle for RoboFinancer UI Design. The original project is available at https://www.figma.com/design/LTA9veTukQnuDQ0WU6ylI0/RoboFinancer-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  